function [testAges, trainingAges]=getAgesForClass(splitNumber, permutationFileName, splitsFileName, allAgesFileName)
allAges=load(allAgesFileName);
splits=load(splitsFileName);
permutations=load(permutationFileName);

[testIndices, trainingIndices]=getTestAndTrainingCases(permutations.datasetPermutations, 1, splits.trainingIndices, splits.testIndices, splitNumber);
testAges=allAges.allAges(testIndices);
trainingAges=allAges.allAges(trainingIndices);
