function [testCases, trainingCases]=getTestAndTrainingCases(datasetPermutations, permutationNumber, trainingIndices, testIndices, splitNumber)
%function [testCases, trainingCases]=getTestAndTrainingCases(datasetPermutations, permutationNumber, trainingIndeces, testIndices, splitNumber)

currentPermutation=squeeze(datasetPermutations(permutationNumber, :));
testCases=currentPermutation(testIndices(splitNumber).data);
trainingCases=currentPermutation(trainingIndices(splitNumber).data);
